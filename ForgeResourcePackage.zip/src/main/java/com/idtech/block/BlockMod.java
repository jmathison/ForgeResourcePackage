package com.idtech.block;

public class BlockMod {
	
	public static void preInit(){
		
	}
	
	public static void init(){
		
		
	}

}
