package com.idtech.block;

public class BlockBuilding extends QuickBlock {

    {
        name = "Building Block";
        texture = "buildingblock";
    }
    
}