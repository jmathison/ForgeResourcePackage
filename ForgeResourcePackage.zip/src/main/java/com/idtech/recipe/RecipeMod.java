package com.idtech.recipe;

public class RecipeMod {
	
	public static void init(){
		// Add your crafting recipes here.
	}
	
}
