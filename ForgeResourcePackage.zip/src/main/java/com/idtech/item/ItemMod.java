package com.idtech.item;

public class ItemMod {
	
	// Material
	

	// Tools

	public static void preInit(){

		// Materials		
		
		// Tools

	}

	public static void init(){

		// Items

	}
}